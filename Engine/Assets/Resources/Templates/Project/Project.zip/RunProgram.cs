﻿sealed class RunProgram
{
    [STAThread]
    private static void Main() =>
        new Engine.Program().Run(true);
}
